public class Ejercicio_a1{

    public static void main(String[] args){
        Punto p1 = new Punto();
        Punto p2 = new Punto();
        Punto p3 = new Punto();

        p1.setPosition(5, 0, 1);
        p2.setPosition(10, 10, 2);
        p3.setPosition(-3, 7, 3);
    }
}