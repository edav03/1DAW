public class Punto{

    public void setPosition(int x, int y, int cont){
        

        System.out.println("PUNTO " + cont + ":");

        System.out.println(" X: " + x + "\n Y: " + y);
        
    }

}