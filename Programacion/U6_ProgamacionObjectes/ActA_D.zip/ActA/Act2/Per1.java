public class Per1 {

    int dni;
    String nombre;
    String apellidos;
    int edad;

}
