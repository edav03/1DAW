public class Per2 {

    int dni;
    String nombre;
    String apellidos;
    int edad;

}
