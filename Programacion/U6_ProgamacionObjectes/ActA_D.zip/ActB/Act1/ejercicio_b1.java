public class ejercicio_b1{

    public static void main(String[] args){
        punto p = new punto(2, 5);
        
        System.out.println("Coordenadas del objeto p: (" + p.x + ", " + p.y + ")");
    }
}