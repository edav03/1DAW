public class punto {
    
    int x;
    int y;
    
    public punto(int x, int y){

        this.x = x;
        this.y = y;
    }

}
