public class ejercicio_b2{
    public static void main(String[] args){

        persona p1 = new persona("20059634T", "Edison", "Alcocer", 18);

        System.out.println(p1.nombre + " " + p1.apellidos + " con DNI: " + p1.dni + " tiene " + p1.edad + " años");
    }
}