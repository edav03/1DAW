public class persona {

    String dni;
    String nombre;
    String apellidos;
    int edad;
    
    public persona(String dni, String nombre, String apellidos, int edad){
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
    }
}
