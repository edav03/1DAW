public class ejercicio_b3{

    public static void main(String[] args){

        coordenadas c1 = new coordenadas(5, 0, 0, 6);
    }
}