public class ejercicio_c3{
    public static void main(String[] args){
    }
}